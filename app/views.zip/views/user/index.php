<div class="d-flex  container-fluid " id="AboutUs" style="
background-color: #FBF8F1;">

<div class="shadow" style="margin: 100px 500px;
  width: 100%;
  padding: 10px;">
    

<form style="margin-top: 10px; position: center; padding-left: 5px;" action="<?= BASEURL; ?>user/tambah" method="post">
    <div class="row" style="position: center; width: 210%;">
        <div class="col-lg-6">
            <?php Flasher::flash(); ?>
        </div>
    </div>
    <div class="mb-3">
        <h2>
            Sign Up
        </h2>
    </div>
    <div class="mb-3">
        <label for="nama" class="form-label">Nama</label>
        <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan Nama" required oninvalid="this.setCustomValidity('Nama tidak boleh kosong')" oninput="this.setCustomValidity('')">
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Alamat Email</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email" required oninvalid="this.setCustomValidity('Email tidak boleh kosong')" oninput="this.setCustomValidity('')">
    </div>
    <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="username" class="form-control" id="username" name="username" placeholder="Masukkan Username" required oninvalid="this.setCustomValidity('Username tidak boleh kosong')" oninput="this.setCustomValidity('')">
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required oninvalid="this.setCustomValidity('Masukkan Password')" oninput="this.setCustomValidity('')">
    </div>
    <div class="mb-1">
        <button type="submit" class="btn btn-primary container-fluid"> Daftar</button>
        
    </div>
    <div class="mb-3">
        <p>Sudah punya account? <a href="<?=BASEURL;?>login/" style="text-decoration: none;">Login</a></p>
    </div>
</form>

</div>





</div>