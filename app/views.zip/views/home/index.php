<div class="d-flex  container-fluid " style="background-color: #FBF8F1;">

		<div class="float-start " style="
		padding-top: 90px;
		
		padding-right: 50px;
		padding-bottom: 20px;
		">
			<img src="../public/img/Home-phone.png" alt="" class="" style="height: 550px; width: 550px; margin-left: -13px; margin-top: 10px;">
		</div>

		<div class="jumbotron ms-1 float-end " 
		style="
		padding-top: 150px;
		padding-left: 90px;
		padding-right: 50px;
		">
			<h1 class="display-4" style="font-family: sans-serif;"><b>Jasa Content Creator Profesional</b></h1>
			<p class="lead">Apa yang akan anda dapatkan di Boroboro.com?</p>
			<ul>
				<li>Tim Creator yang handal pada bidangnya</li>
				<li>Berkonsultasi langsung dengan para Creator</li>
				<li>Konten yang menarik, kreatif, dan berkualitas</li>
			</ul>
			<hr class="my-4">
			<a class="btn  btn-lg" href="#creator" role="button" style="font-family: sans-serif;; background-color : #54BAB9; ">Content Creator</a>
			<span>or</span>
			<a class="btn  btn-lg " href="#foto" role="button" style="font-family: sans-serif;; background-color : #54BAB9;">Pengguna Jasa</a>
		</div>

	
</div>

<div class="d-flex  container-fluid " id="AboutUs" style="
background-color: #FBF8F1;
padding-bottom: 20px;">

		<div class="jumbotron ms-1 float start" 
			style="
			padding-top: 150px;
			padding-left: 90px;
			padding-right: 50px;
			padding-bottom: 90px;
		">

			<h1 class="display-4" style="font-family: times-new-roman, sans-serif;"><b>About Us</b></h1>
			<hr class="my-4">
			<p class="lead">Boroboro.com adalah Web freelancing dan crowdsourcing terbesar di dunia berdasarkan jumlah pengguna dan proyek. Kami menghubungkan lebih dari 10,000 para pemberi kerja dan freelancer secara global lebih dari 20 negara, daerah dan wilayah. Melalui Web kami, para pemberi kerja dapat mempekerjakan freelancer untuk melakukan pekerjaan di terkhusus di bidang Photographer dan UI/UX Design.
			</p>
		</div>


		<div class="float-end " style="
			padding-top: 80px;
			padding-left: 50px;
			padding-right: 50px;
			padding-bottom: 20px;
			">
			<img src="../public/img/mom.png" alt="" class="" style="height: 500px; width: 400px; margin-left: 50px;  margin-top: 10px;">
		</div>

</div>

<div class="container-fluid " id="creator" style="
background-color: #FBF8F1;

padding-left: 50px;
padding-right: 50px;
padding-bottom: 5px;
;">
	<div class="jumbotron ms-1 float start" 
			style="
			padding-top: 70px;
			padding-left: 50px;
			padding-right: 50px;
			padding-bottom: 0;
		">

			<h1 class="display-4" style="font-family: times-new-roman, sans-serif;" ><b>Content Creator</b></h1>
		</div>
		
<div id="carouselExampleCaptions " class="carousel slide " data-bs-ride="carousel" >
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner" >
    <div class="carousel-item active "  data-bs-interval="3000">
      <img src="../public/img/slide1.jpg" class="d-block w-100 rounded"  alt="..." height="600px" style="
		padding: 50px;
		margin-top: -35px;
		">
      <div class="carousel-caption d-none d-md-block">
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item"  data-bs-interval="3000">
      <img src="../public/img/slide2.jpg" class="d-block w-100 rounded"  alt="..." height="600px" style="
		padding: 50px;
		margin-top: -35px;
		">
      <div class="carousel-caption d-none d-md-block">
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item"  data-bs-interval="3000">
      <img src="../public/img/slide3.jpg" class="d-block w-100 rounded"  alt="..." height="600px" style="
		padding: 50px;
		margin-top: -35px;
		">
      <div class="carousel-caption d-none d-md-block">
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<div class="d-flex container-fluid " style="background-color: #FBF8F1;">
	<div class="container-md text-center p-3 rounded" id="foto" style="margin: 10px; padding: 5px; height: 500px; background-color: #FBF8F1;">
		<h3 >Fotografer</h3>

		<div class="container mt-4">
			<div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
				<div class="carousel-inner">
					<div class="carousel-item active"  data-bs-interval="2000">
					<img src="../public/img/foto/f10.jpg" class="d-block w-100 " alt="..." style="border-radius: 10%; object-fit: cover; width: 800px; height: 400px;">
					</div>
					<div class="carousel-item">
					<img src="../public/img/foto/f15.jpg" class="d-block w-100"  alt="..." style="border-radius: 10%; object-fit: cover; width: 800px; height: 400px;">
					</div>
					<div class="carousel-item">
					<img src="../public/img/foto/f13.jpg" class="d-block w-100"  alt="..." style="border-radius: 10%; object-fit: cover; width: 800px; height: 400px;">
					</div>
				</div>
				<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Previous</span>
				</button>
				<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Next</span>
				</button>
			</div>
			<div class=" mt-3">
				<a href="<?=BASEURL;?>photographer" class="btn" style="
          font-family: sans-serif;
          background-color: #54BAB9;
          ">Go somewhere</a>
			</div>
			
		</div>
	</div>
	<div class="container-md text-center p-3 rounded" id="design" style="margin: 10px; padding: 5px; height: 500px; background-color: #FBF8F1;">
		<h3 >UI Designer</h3>

		<div class="container mt-4">
			<div id="carouselExampleFade1" class="carousel slide carousel-fade" data-bs-ride="carousel">
				<div class="carousel-inner">
					<div class="carousel-item active"  data-bs-interval="2000">
					<img src="../public/img/foto/d1.gif" class="d-block w-100 " alt="..." style="border-radius: 10%; object-fit: cover; width: 800px; height: 400px;">
					</div>
					<div class="carousel-item">
					<img src="../public/img/foto/d5.png" class="d-block w-100" alt="..." style="border-radius: 10%; object-fit: cover; width: 800px; height: 400px;">
					</div>
					<div class="carousel-item">
					<img src="../public/img/foto/d8.jpg" class="d-block w-100" alt="..." style="border-radius: 10%; object-fit: cover; width: 800px; height: 400px;">
					</div>
				</div>
				<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade1" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Previous</span>
				</button>
				<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade1" data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Next</span>
				</button>
			</div>
			<div class=" mt-3">
				<a href="<?=BASEURL;?>desain" class="btn" style="
          font-family: sans-serif;
          background-color: #54BAB9;
          ">Go somewhere</a>
			</div>
		</div>
	</div>
</div>
