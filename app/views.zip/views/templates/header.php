<!DOCTYPE html>
<html lang="en">
<head>
  

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $data['judul']; ?></title>
    <link rel="stylesheet" href="css/custom.css">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <nav class="navbar navbar-light navbar-expand-lg fixed-top opacity-100" style="background-color: #F7ECDE;" >
      <div class="container-fluid" >
        <a class="navbar-brand" href="<?=BASEURL;?>home"> <span style="color: #54BAB9;"><b>Boroboro.com</b></span> 
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse float-start" id="navbarNav" >
          <ul class="navbar-nav  ">
            <li class="nav-item ">
              <a class="nav-link active" aria-current="page" href="<?=BASEURL;?>home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="<?=BASEURL;?>#AboutUs">About</a>
            </li>
            <li class="nav-item dropdown">
            <!-- <a class="nav-link active dropdown-toggle" data-bs-toggle="dropdown" role="button"  aria-expanded="false" aria-current="page" href="#Service">Services</a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?=BASEURL;?>photographer">Photographer</a></li>
                <li><a class="dropdown-item" href="<?=BASEURL;?>desain">UI Designer</a></li>
              </ul> -->
              <a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button"  aria-expanded="false" aria-current="page" href="#Service">Services</a>
              
              <ul class="dropdown-menu small-menu">
                <li><a class="dropdown-item" href="<?=BASEURL;?>photographer">Photographer</a></li>
                <li><a class="dropdown-item" href="<?=BASEURL;?>desain">UI Designer</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#footer">Contact</a>
            </li>   
          </ul>
        </div>
        <div class="d-flex justify-content-end" >
          <a class="nav-link active ms-2" href="<?=BASEURL;?>user" style="padding: 0;">
            <span class="btn btn-sm " href="#" role="button" style="
            font-family: sans-serif;
            background-color: #54BAB9;
            "><b>
                Join Us
            </b> 
            </span>
          </a>
          <a class="nav-link active ms-2" href="<?=BASEURL;?>login" style="padding: 0;">
            <span class="btn btn-sm " href="#" role="button" style="
            font-family: sans-serif;
            background-color: #54BAB9;
            "><b>
                Login
            </b> 
            </span>
          </a>
       </div>
    </nav>
</head>
<body style="
background-color: #FBF8F1;">

