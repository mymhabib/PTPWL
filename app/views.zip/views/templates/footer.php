<div class="container" style="margin-top: 90px; background-color: #FBF8F1; " id="footer">
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <div class="col-md-4 d-flex align-items-center">
            <a href="#" class="col-md-4 d-flex align-items-center link-dark" style="text-decoration: none;">
                <h5>
                    <b>
                        boroboro.com
                    </b>
                </h5>
            </a>
            <span class="text-muted">© 2021 Company, Inc</span>
        </div>
        <div class="justify-content-end col-md-4 align-items-center">
            <h6>
                <b>Hubungi Kami</b>
            </h6>
            <p>Jl. Apa aja No. Berapa aja, Kota dimana aja</p>
            <p>081234567890</p>
            <p>emailnyaapaya@gmail.com</p> 
        </div>
            
                <ul class="nav col-md-4 justify-content-end list-unstyled d-flex align-items-end">
                    <li class="ms-3">
                        <a class="text-muted " target="blank" href="https://instagram.com/unikom_official?utm_medium=copy_link">
                            <img src="<?=BASEURL;?>img/logo-ig.png" alt="" height="40px" width="40px">
                        </a>
                    </li>
                    <li class="ms-3">
                        <a class="text-muted " target="blank" href="https://www.facebook.com/unikombandungofficial">
                            <img src="<?=BASEURL;?>img/logo-fb.png" alt="" height="40px" width="40px">
                        </a>
                    </li>
                    <li class="ms-3">
                        <a class="text-muted " target="blank" href="https://mobile.twitter.com/unikomtwit">
                            <img src="<?=BASEURL;?>img/logo-twitter.png" alt="" height="40px" width="40px">
                        </a>
                    </li>
            </ul>
            

    </footer>

</div>


<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="<?= BASEURL;?>/js/bootstrap.js"></script>
<script src="<?= BASEURL;?>/js/script.js"></script>
</body>
</html>