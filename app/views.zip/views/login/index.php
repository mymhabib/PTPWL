<div class="d-flex  container-fluid " id="AboutUs" style="
background-color: #FBF8F1;">
<link rel="stylesheet" href="css/custom.css">

<div class="shadow" style="margin: 100px 500px;
  width: 50%;
  padding: 10px;">

<form style="margin-top: 10px; position: center; padding-left: 5px;" action="<?= BASEURL; ?>login/run" method="post">
    <div class="mb-3">
        <h2>
            Login
        </h2>
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email" required oninvalid="this.setCustomValidity('Email tidak boleh kosong')" oninput="this.setCustomValidity('')">
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required oninvalid="this.setCustomValidity('Masukkan Password')" oninput="this.setCustomValidity('')">
    </div>
    <div class="mb-1">
        <button type="submit" class="btn btn-primary container-fluid">Login</button>
    </div>
    <div class="mb-3">
        <p>Belum punya account? <a href="<?=BASEURL;?>user" style="text-decoration: none;">Daftar</a></p>
    </div>
</form>

</div>
</div>