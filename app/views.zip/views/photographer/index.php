
<div class="d-flex flex-column container-fluid" style="Background-color : #FBF8F1;">
    <div class="jumbotron ms-1 " 
		style="
        padding-top: 70px;
        padding-left : 50px;
        padding-right: 50px;
        padding-bottom: 50px;
		">
			<h1 class="display-4" style="font-family: sans-serif;"><b>Photographer</b></h1>
    </div>
    <div class="d-flex mt-5 shadow-sm " style="padding: 30px;">
        <div class="card container p-2 mb-3" style="width: 600px; height: 300px;">
            <div class="row g-0">
                <div class="col-md-4">
                <img src="../public/img/photo2.jpg" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title">Eli</h5>
                    <p class="card-text">Hai, Nama saya Eli, saya seorang Website Designer, Developer & SEO, UI/UX Designer Marketing Specialist dengan pengalaman lebih dari 12+ tahun.</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <a href="whatsapp://send?text=Hello&phone=+6285794220941" class="btn btn-primary" style="background-color: #45ba2f;"><img src="../public/img/logo-wa.png" height="40px" width="40px" style="margin-left: -5px; margin-right: 3px;"> Contact Me </a>

                </div>
                </div>
            </div>
        </div>

        <div id="carouselExampleIndicators1" class="container carousel slide" data-bs-ride="carousel" style=" margin: auto; ">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleIndicators1" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators1" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators1" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                <img src="../public/img/foto/f1.jpg" class="d-block w-100" alt="..." style="height: 600px; object-fit: contain;  ">
                </div>
                <div class="carousel-item">
                <img src="../public/img/foto/f2.jpg" class="d-block w-100" alt="..." style="height: 600px; object-fit: contain;  ">
                </div>
                <div class="carousel-item">
                <img src="../public/img/foto/f3.jpg" class="d-block w-100" alt="..." style="height: 600px; object-fit: contain;  ">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators1" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators1" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

    

    <div class="d-flex mt-5 shadow-sm " style="padding: 30px;">

    <div class="card container p-2 mb-3" style="width: 600px; height: 300px;">
            <div class="row g-0">
                <div class="col-md-4">
                <img src="../public/img/photo3.jpg" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title">Eli</h5>
                    <p class="card-text">Hai, Nama saya Eli, saya seorang Website Designer, Developer & SEO, UI/UX Designer Marketing Specialist dengan pengalaman lebih dari 12+ tahun.</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <a href="whatsapp://send?text=Hello&phone=+6285794220941" class="btn btn-primary" style="background-color: #45ba2f;"><img src="../public/img/logo-wa.png" height="40px" width="40px" style="margin-left: -5px; margin-right: 3px;"> Contact Me </a>

                </div>
                </div>
            </div>
        </div>


        <div id="carouselExampleIndicators2" class="container carousel slide" data-bs-ride="carousel" style=" margin: auto; ">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleIndicators2" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators2" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators2" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                <img src="../public/img/foto/f4.jpg" class="d-block w-100" alt="..." style="height: 600px; object-fit: contain;  ">
                </div>
                <div class="carousel-item">
                <img src="../public/img/foto/f5.jpg" class="d-block w-100" alt="..." style="height: 600px; object-fit: contain;  ">
                </div>
                <div class="carousel-item">
                <img src="../public/img/foto/f6.jpg" class="d-block w-100" alt="..." style="height: 600px; object-fit: contain;  ">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators2" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators2" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
            </div>

    </div>

    <div class="d-flex mt-5 shadow-sm " style="padding: 30px;">

        <div class="card container p-2 mb-3" style="width: 600px; height: 300px;">
            <div class="row g-0">
                <div class="col-md-4">
                <img src="../public/img/photo4.jpg" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title">Eli</h5>
                    <p class="card-text">Hai, Nama saya Eli, saya seorang Website Designer, Developer & SEO, UI/UX Designer Marketing Specialist dengan pengalaman lebih dari 12+ tahun.</p>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    <a href="whatsapp://send?text=Hello&phone=+6285794220941" class="btn btn-primary" style="background-color: #45ba2f;"><img src="../public/img/logo-wa.png" height="40px" width="40px" style="margin-left: -5px; margin-right: 3px;"> Contact Me </a>

                </div>
                </div>
            </div>
        </div>


        <div id="carouselExampleIndicators" class="container carousel slide" data-bs-ride="carousel" style=" margin: auto;">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                <img src="../public/img/foto/f7.jpg" class="d-block w-100" alt="..." style="height: 600px; object-fit: contain;  ">
                </div>
                <div class="carousel-item">
                <img src="../public/img/foto/f8.jpg" class="d-block w-100" alt="..." style="height: 600px; object-fit: contain;  ">
                </div>
                <div class="carousel-item">
                <img src="../public/img/foto/f9.jpg" class="d-block w-100" alt="..." style="height: 600px; object-fit: contain;  ">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev" >
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
            </div>
    </div>
        
</div>
